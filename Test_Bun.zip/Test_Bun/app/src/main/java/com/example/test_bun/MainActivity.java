package com.example.test_bun;

import android.app.Fragment;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;

import com.example.test_bun.databinding.ActivityMainBinding;

public class MainActivity extends Activity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        replaceFragment(new HomeFragment());
        binding.bottomNavigationView.setBackground(null);

        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            if(item.getItemId() == R.id.home) {
                replaceFragment(new HomeFragment());
            }
            else if(item.getItemId() == R.id.shorts) {
                replaceFragment(new ShortsFragment());
            }
            else if(item.getItemId() == R.id.subscriptions) {
                replaceFragment(new SubscriptionsFragment());
            }
            else if(item.getItemId() == R.id.library) {
                replaceFragment(new LibraryFragment());
            }
//            switch (item.getItemId()) {
//                case R.id.home:
//                    replaceFragment(new HomeFragment());
//                    break;
//
//                case R.id.shorts:
//                    replaceFragment(new ShortsFragment());
//                    break;
//
//                case R.id.subscriptions:
//                    replaceFragment(new SubscriptionsFragment());
//                    break;
//
//                case R.id.library:
//                    replaceFragment(new LibraryFragment());
//                    break;
//            }
            return true;

        });

    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }
}